WINMERGE

WinMerge este un utilitar cu Surs� Deschis� de comparare �i fuziune 
de fi�iere care ruleaz� pe toate versiunile moderne ale sistemului
de operare Windows. Unele func�ionalit��i necesit� instalarea de
componente adi�ionale.

Ultima versiune de WinMerge �i alte informa�ii despre WinMerge sunt
disponibile la
https://winmerge.org

Start rapid c�tre utilizarea WinMerge:
Citi�i capitolul Quick-start din manualul on-line pentru a v�
familiariza cu WinMerge:
https://manual.winmerge.org/Quick_start.html

Manualul HTML:
Manualul este disponibil la
https://manual.winmerge.org/
este posibil s�-l ave�i instalat (dac� s-a optat pentru aceasta) local,
dar este �i copiabil separat de la https://winmerge.org/
(vezi documenta�ia)

Suportul pentru scripturi:
Dac� dori�i s� lucra�i cu scripturi ave�i nevoie ca Windows Scripting Host
s� fie instalat. Dac� observa�i erori care au ca surs� scripturile, vizita�i
https://msdn.microsoft.com/library/default.asp?url=/downloads/list/webdev.asp
�i verifica�i daca Windows Scripting Host este la zi �i func�ionabil.

Suport:
Dezvoltatorii r�spund la �ntreb�ri pe forumul WinMerge de la Sourceforge.net:
https://sourceforge.net/forum/?group_id=13216

Defecte �i solicitarea de noi func�ionalit��i:
Defectele �i solicitarea de noi func�ionalit��i trebuie �nregistrate pe
listele de Defecte (Bugs) �i Func�ionalit��i (RFE) de la sourceforge.net.

Lista de defecte:
https://sourceforge.net/tracker/?group_id=13216&atid=113216
Atunci c�nd �nregistra�i un defect, v� rug�m s� ne spune�i versiunea de
WinMerge pe care o folosi�i! WinMerge versiunea 2.2.0 sau mai noi pot
scrie configurarea sub care ruleaz� �ntr-un fi�ier.
Aceast� comand� este accesibil� din meniul Ajutor/Configurare.
V� rug�m s� ata�a�i �i aceast� informa�ie (ca un ata�ament) la raportarea
dumneavoastr�, con�ine informa�ii pentru dezvoltatori.

Lista pentru �nregistratea de solicit�ri de noi func�ionalit��i (RFE):
https://sourceforge.net/tracker/?group_id=13216&atid=363216


- Dezvoltatorii WinMerge
