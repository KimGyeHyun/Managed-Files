Here are some common git-tfs problems.

* [Checkin policy doesn't work](troubleshooting-checkin-policies.md)
* [TF400813 error with visualstudio.com](TF400813-error-with-visualstudio.com.md)
* [Set custom workspace to bypass errors due to NTFS length path limits of 259 characters](Set-custom-workspace.md)
* [TFS has no branches](Tfs-has-no-branches.md)
