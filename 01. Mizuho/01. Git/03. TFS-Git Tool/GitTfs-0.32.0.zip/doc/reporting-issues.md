If you want to report an issue, please give us these informations :
- the version of git-tfs you use : `git tfs info`
- the version of TFS you use (and if that is migrated from a previous version)
- the version of Visual Studio or Team Explorer Everywhere you use (if possible)
- the debug informations when the bug could be reproduce. Just add the option `-d` to the command that do crash.
- and like all good reporting, the most informations you can on the context and what you are trying to do and steps to reproduce the problem (if possible)