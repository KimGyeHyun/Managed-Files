Clean all workspace directories (i.e. `.git\tfs\default\workspace` and workspace for branches) which are used for fetching and checkin changesets from TFS and also do what [cleanup-workspaces](cleanup-workspaces.md) does: clean up leftover TFS workspace mappings created by git-tfs.

This command could be run periodically to free some space.
